from django.apps import AppConfig


class GdscAppConfig(AppConfig):
    name = 'Gdsc_app'
