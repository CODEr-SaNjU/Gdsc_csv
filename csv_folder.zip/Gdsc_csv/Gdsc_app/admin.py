from django.contrib import admin
from .models import Documents
# Register your models here.



admin.site.register(Documents)